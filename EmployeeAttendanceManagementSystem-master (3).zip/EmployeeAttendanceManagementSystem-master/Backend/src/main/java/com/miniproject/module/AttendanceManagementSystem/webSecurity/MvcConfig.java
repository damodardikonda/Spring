//package com.miniproject.module.AttendanceManagementSystem.webSecurity;
//
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//public class MvcConfig implements WebMvcConfigurer {
//
//}
