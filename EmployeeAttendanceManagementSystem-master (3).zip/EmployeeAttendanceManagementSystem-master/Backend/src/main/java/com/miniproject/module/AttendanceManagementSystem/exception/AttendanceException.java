package com.miniproject.module.AttendanceManagementSystem.exception;

public class AttendanceException extends RuntimeException {

	public AttendanceException(String msg) {
		super(msg);
	}
}
