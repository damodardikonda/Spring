
export class Profile {
    empId!:number;
	emp_name!:String;
	emp_designation!:number;
	emp_doj!:String;
	department_deptid!:number;
    emp_mobile!:String;
	emp_email!:String;

}