import { department } from "./department";
export class AddEmployee {
	emp_name!:String;
	emp_designation!:string;
    emp_mobile!:String;
	emp_email!:String;
    department!:{
        deptid:string
    }

}