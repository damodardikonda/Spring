export class department {
    deptid!:number
    dept_name!:string
}